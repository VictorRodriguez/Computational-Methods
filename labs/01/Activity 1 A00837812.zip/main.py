# esta primera función itera el set que le dimos y revisa si hay reflexividad y regresa true o false
def is_reflexive(relation, set_size):
  for element in range(set_size):
      if (element, element) not in relation:
          return False
  return True
# esta segunda función itera el set que le dimos y revisa si hay simetría y regresa true o false
def is_symmetric(relation):
  for pair in relation:
      if (pair[1], pair[0]) not in relation:
          return False
  return True

# esta tercera función itera el set que le dimos y revisa si hay transitividad y regresa true o false
def is_transitive(relation):
  for x, y in relation:
      for z, w in relation:
          if y == z and (x, w) not in relation:
              return False
  return True

# Por último aquí determinamos el tipo de relación que se tiene en el set
def determine_relation_properties(relation, set_size):
  reflexive = is_reflexive(relation, set_size)
  symmetric = is_symmetric(relation)
  transitive = is_transitive(relation)

  print("(a) R is", "reflexive," if reflexive else "not reflexive,")
  print("(b) R is", "symmetric," if symmetric else "not symmetric,")
  print("(c) R is", "transitive," if transitive else "not transitive,")
  print("(d) R", "has equivalence relation." if (reflexive and symmetric and transitive) 
    else "doesnt have equivalence relation.")



# ejemplo con el set que nos piden
input_relation = {(0, 0), (0, 1), (0, 3), (1, 0), (1, 1), (2, 2), (3, 0), (3, 3)}
set_size = 4  

determine_relation_properties(input_relation, set_size)



# esta función genera el script donde se muestra las relaciones de un set
def generate_graphviz_script(relation):
  script = "digraph example {\n\n\trankdir=LR;\n\tnode [shape = circle];\n"

  for pair in relation:
      script += f"\t{pair[0]} -> {pair[1]} ;\n"

  script += "\n}"

  with open("graph.log", "w") as file:
      file.write(script)

# ejemplo con el set que nos piden
input_relation = {(0, 0), (0, 1), (0, 3), (1, 0), (1, 1), (2, 2), (3, 0), (3, 3)}

generate_graphviz_script(input_relation) 
